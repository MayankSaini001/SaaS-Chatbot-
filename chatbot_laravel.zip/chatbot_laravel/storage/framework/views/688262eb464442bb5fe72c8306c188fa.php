

<?php $__env->startSection('content'); ?>
<div class="max-w-4xl mx-auto">

    <div class="flex justify-between items-center mb-6">
        <h1 class="text-2xl font-bold text-gray-800">Team Members</h1>
        <span class="text-sm text-gray-500"><?php echo e($agents->count()); ?> agent(s)</span>
    </div>

    
    <?php
        $planLimits = ['basic' => 2, 'pro' => 10, 'enterprise' => 999];
        $tenant = auth()->user()->tenant ?? \App\Models\Tenant::find(auth()->user()->tenant_id);
        $maxAgents = $planLimits[$tenant->plan ?? 'basic'] ?? 2;
        $limitReached = $agents->count() >= $maxAgents;
    ?>

    
    <div class="bg-white rounded-xl shadow-sm border p-6 mb-6">
        <div class="flex items-center justify-between mb-4">
            <h2 class="font-semibold text-gray-700">Add New Agent</h2>
            <span class="text-xs px-3 py-1 rounded-full font-medium <?php echo e($limitReached ? 'bg-red-100 text-red-600' : 'bg-green-100 text-green-700'); ?>">
                <?php echo e($agents->count()); ?> / <?php echo e($maxAgents == 999 ? '∞' : $maxAgents); ?> agents used
            </span>
        </div>

        <form method="POST" action="<?php echo e(route('agent.agents.add')); ?>" class="flex flex-col md:flex-row gap-3">
            <?php echo csrf_field(); ?>
            <input type="text" name="name" placeholder="Full Name" required
                <?php echo e($limitReached ? 'disabled' : ''); ?>

                class="flex-1 border rounded-lg px-4 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-400 <?php echo e($limitReached ? 'bg-gray-100 cursor-not-allowed opacity-60' : ''); ?>">
            <input type="email" name="email" placeholder="Email" required
                <?php echo e($limitReached ? 'disabled' : ''); ?>

                class="flex-1 border rounded-lg px-4 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-400 <?php echo e($limitReached ? 'bg-gray-100 cursor-not-allowed opacity-60' : ''); ?>">
            <input type="password" name="password" placeholder="Password" required
                <?php echo e($limitReached ? 'disabled' : ''); ?>

                class="flex-1 border rounded-lg px-4 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-400 <?php echo e($limitReached ? 'bg-gray-100 cursor-not-allowed opacity-60' : ''); ?>">
            <select name="role"
                <?php echo e($limitReached ? 'disabled' : ''); ?>

                title="Agent: full access to reply/resolve chats. Viewer: read-only access."
                class="border rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-400 <?php echo e($limitReached ? 'bg-gray-100 cursor-not-allowed opacity-60' : ''); ?>">
                <option value="agent">Agent (full access)</option>
                <option value="viewer">Viewer (read-only)</option>
            </select>
            <button type="submit"
                <?php echo e($limitReached ? 'disabled' : ''); ?>

                class="px-6 py-2 rounded-lg text-sm whitespace-nowrap font-semibold <?php echo e($limitReached ? 'bg-gray-300 text-gray-500 cursor-not-allowed' : 'bg-indigo-600 text-white hover:bg-indigo-700'); ?>">
                + Add Agent
            </button>
        </form>

        <?php if($limitReached): ?>
        <div class="mt-3 flex items-center gap-2 p-3 bg-amber-50 border border-amber-200 rounded-lg">
            <svg class="w-4 h-4 text-amber-500 flex-shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 9v2m0 4h.01M10.29 3.86L1.82 18a2 2 0 001.71 3h16.94a2 2 0 001.71-3L13.71 3.86a2 2 0 00-3.42 0z"/>
            </svg>
            <span class="text-sm text-amber-700">
                Agent limit reached for your <strong class="capitalize"><?php echo e($tenant->plan); ?></strong> plan (max <?php echo e($maxAgents); ?>).
                <a href="<?php echo e(route('billing.pricing')); ?>" class="underline font-semibold text-indigo-600 ml-1">Upgrade plan →</a>
            </span>
        </div>
        <?php endif; ?>

        <?php if(session('success')): ?>
        <div class="mt-3 text-sm text-green-600 font-medium">✓ <?php echo e(session('success')); ?></div>
        <?php endif; ?>
        <?php if(session('error')): ?>
        <div class="mt-3 text-sm text-red-600 font-medium">✗ <?php echo e(session('error')); ?></div>
        <?php endif; ?>
    </div>

    
    <div class="bg-white rounded-xl shadow-sm border overflow-hidden">
        <table class="w-full text-sm">
            <thead class="bg-gray-50 border-b">
                <tr>
                    <th class="text-left px-6 py-3 text-xs font-semibold text-gray-500 uppercase">Agent</th>
                    <th class="text-left px-6 py-3 text-xs font-semibold text-gray-500 uppercase">Role</th>
                    <th class="text-left px-6 py-3 text-xs font-semibold text-gray-500 uppercase">Status</th>
                    <th class="text-left px-6 py-3 text-xs font-semibold text-gray-500 uppercase">Last Seen</th>
                    <th class="text-left px-6 py-3 text-xs font-semibold text-gray-500 uppercase">Conversations</th>
                    <th class="px-6 py-3"></th>
                </tr>
            </thead>
            <tbody class="divide-y">
                <?php $__empty_1 = true; $__currentLoopData = $agents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $agent): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr class="hover:bg-gray-50 transition">
                    <td class="px-6 py-4">
                        <div class="flex items-center gap-3">
                            <div class="w-9 h-9 rounded-full bg-indigo-100 flex items-center justify-center text-indigo-600 font-bold text-sm flex-shrink-0" style="overflow:hidden;">
                                <?php if($agent->avatar): ?>
                                    <img src="<?php echo e($agent->avatar); ?>" alt="<?php echo e($agent->name); ?>" style="width:100%;height:100%;object-fit:cover;">
                                <?php else: ?>
                                    <?php echo e(strtoupper(substr($agent->name, 0, 1))); ?>

                                <?php endif; ?>
                            </div>
                            <div>
                                <div class="font-medium text-gray-800">
                                    <?php echo e($agent->name); ?>

                                    <?php if($agent->id === auth()->id()): ?>
                                    <span class="text-xs text-indigo-500 font-normal">(You)</span>
                                    <?php endif; ?>
                                </div>
                                <div class="text-xs text-gray-400"><?php echo e($agent->email); ?></div>
                            </div>
                        </div>
                    </td>
                    <td class="px-6 py-4">
                        <?php if($agent->id === auth()->id()): ?>
                        <span class="inline-flex px-2.5 py-1 rounded-full text-xs font-semibold <?php echo e($agent->role === 'viewer' ? 'bg-amber-100 text-amber-700' : 'bg-indigo-100 text-indigo-700'); ?>">
                            <?php echo e(ucfirst($agent->role)); ?>

                        </span>
                        <?php else: ?>
                        <form method="POST" action="<?php echo e(route('agent.agents.role', $agent)); ?>"
                              onchange="this.submit()">
                            <?php echo csrf_field(); ?> <?php echo method_field('PATCH'); ?>
                            <select name="role"
                                class="text-xs font-semibold rounded-full px-2.5 py-1 border-0 focus:outline-none focus:ring-2 focus:ring-indigo-400 cursor-pointer <?php echo e($agent->role === 'viewer' ? 'bg-amber-100 text-amber-700' : 'bg-indigo-100 text-indigo-700'); ?>">
                                <option value="agent" <?php echo e($agent->role === 'agent' ? 'selected' : ''); ?>>Agent</option>
                                <option value="viewer" <?php echo e($agent->role === 'viewer' ? 'selected' : ''); ?>>Viewer</option>
                            </select>
                        </form>
                        <?php endif; ?>
                    </td>
                    <td class="px-6 py-4">
                        <?php
                            $recentlyActive = $agent->is_online && $agent->last_seen && $agent->last_seen->gt(now()->subMinutes(2));
                            $agentStatus = $agent->status ?? 'online';
                        ?>
                        <?php if(!$recentlyActive): ?>
                        <span class="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-semibold bg-gray-100 text-gray-500">
                            <span class="w-1.5 h-1.5 rounded-full bg-gray-400"></span>
                            Offline
                        </span>
                        <?php elseif($agentStatus === 'away'): ?>
                        <span class="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-semibold bg-amber-100 text-amber-700">
                            <span class="w-1.5 h-1.5 rounded-full bg-amber-500"></span>
                            Away
                        </span>
                        <?php elseif($agentStatus === 'busy'): ?>
                        <span class="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-semibold bg-red-100 text-red-700">
                            <span class="w-1.5 h-1.5 rounded-full bg-red-500"></span>
                            Busy
                        </span>
                        <?php else: ?>
                        <span class="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-semibold bg-green-100 text-green-700">
                            <span class="w-1.5 h-1.5 rounded-full bg-green-500 animate-pulse"></span>
                            Online
                        </span>
                        <?php endif; ?>
                    </td>
                    <td class="px-6 py-4 text-gray-500 text-xs">
                        <?php echo e($agent->last_seen ? $agent->last_seen->diffForHumans() : 'Never'); ?>

                    </td>
                    <td class="px-6 py-4 text-gray-600">
                        <?php echo e($agent->conversations()->count()); ?>

                    </td>
                    <td class="px-6 py-4 text-right">
                        <?php if($agent->id !== auth()->id()): ?>
                        <form method="POST" action="<?php echo e(route('agent.agents.delete', $agent)); ?>"
                              onsubmit="return confirm('Remove this agent?')">
                            <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                            <button class="text-xs text-red-500 hover:text-red-700 font-medium">Remove</button>
                        </form>
                        <?php endif; ?>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="6" class="px-6 py-10 text-center text-gray-400">No agents yet.</td>
                </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home4/topscbtk/knights.topscripts.in/chatbot_laravel/resources/views/agent/agents/index.blade.php ENDPATH**/ ?>