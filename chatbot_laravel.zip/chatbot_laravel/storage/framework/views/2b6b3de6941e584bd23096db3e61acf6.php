<?php $__env->startSection('content'); ?>
<?php
    $isViewer = auth()->user()->role === 'viewer';
?>
<div class="max-w-4xl mx-auto">

    <div class="flex justify-between items-center mb-6">
        <h1 class="text-2xl font-bold text-gray-800">Canned Responses</h1>
        <span class="text-sm text-gray-500"><?php echo e($responses->count()); ?> saved repl<?php echo e($responses->count() == 1 ? 'y' : 'ies'); ?></span>
    </div>

    <?php if(!$isViewer): ?>
    
    <div class="bg-white rounded-xl shadow-sm border p-6 mb-6">
        <h2 class="font-semibold text-gray-700 mb-4">Add New Canned Response</h2>

        <form method="POST" action="<?php echo e(route('agent.canned-responses.store')); ?>" class="flex flex-col gap-3">
            <?php echo csrf_field(); ?>
            <input type="text" name="title" placeholder="Short title (e.g. Greeting, Payment Issue)" required
                class="border rounded-lg px-4 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-400">
            <textarea name="body" rows="3" placeholder="Full message text agents will send..." required
                class="border rounded-lg px-4 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-400 resize-none"></textarea>
            <button type="submit"
                class="self-start px-6 py-2 rounded-lg text-sm font-semibold bg-indigo-600 text-white hover:bg-indigo-700">
                + Add Response
            </button>
        </form>

        <?php if(session('success')): ?>
        <div class="mt-3 text-sm text-green-600 font-medium">✓ <?php echo e(session('success')); ?></div>
        <?php endif; ?>
    </div>
    <?php else: ?>
    <div class="mb-6 text-sm text-center py-3 rounded-xl" style="background:#f5f3ff;color:#7c3aed;border:1px solid #ede9fe;font-weight:500;">
        👁️ You have read-only (Viewer) access — only Agents and Owners can add or delete responses.
    </div>
    <?php endif; ?>

    
    <div class="bg-white rounded-xl shadow-sm border overflow-hidden">
        <?php $__empty_1 = true; $__currentLoopData = $responses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $response): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <div class="flex items-start justify-between gap-4 px-6 py-4 border-b last:border-0">
            <div class="flex-1 min-w-0">
                <div class="font-medium text-gray-800 text-sm mb-1"><?php echo e($response->title); ?></div>
                <div class="text-xs text-gray-500 line-clamp-2"><?php echo e($response->body); ?></div>
                <div class="text-xs text-gray-400 mt-1.5">Added by <?php echo e($response->author->name ?? 'Agent'); ?></div>
            </div>
            <?php if(!$isViewer): ?>
            <form method="POST" action="<?php echo e(route('agent.canned-responses.destroy', $response)); ?>"
                  onsubmit="return confirm('Delete this canned response?');">
                <?php echo csrf_field(); ?>
                <?php echo method_field('DELETE'); ?>
                <button type="submit" class="text-xs text-red-500 hover:text-red-700 font-medium whitespace-nowrap">
                    Delete
                </button>
            </form>
            <?php endif; ?>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <div class="text-center text-gray-400 text-sm py-10">
            No canned responses yet. Add your first quick reply above.
        </div>
        <?php endif; ?>
    </div>

    <p class="text-xs text-gray-400 mt-4">
        💡 These responses are shared across your whole team and appear as quick-insert options while replying to a conversation.
    </p>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home4/topscbtk/knights.topscripts.in/chatbot_laravel/resources/views/agent/canned-responses/index.blade.php ENDPATH**/ ?>