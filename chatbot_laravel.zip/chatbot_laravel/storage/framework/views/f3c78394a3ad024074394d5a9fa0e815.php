<?php $__env->startSection('content'); ?>
<div class="min-h-screen bg-gray-50">

    
    <div class="bg-white border-b px-4 md:px-8 py-4 md:py-5 flex items-center justify-between">
        <div>
            <h1 class="text-lg md:text-xl font-bold text-gray-800">Analytics</h1>
            <p class="text-xs md:text-sm text-gray-400 mt-0.5">
                <?php echo e($isOwner ? 'Team performance overview' : 'Your performance overview'); ?>

            </p>
        </div>
    </div>

    <div class="px-4 md:px-8 py-4 md:py-6 space-y-4 md:space-y-6">

        
        <div class="grid grid-cols-2 md:grid-cols-4 gap-3 md:gap-4">

            <div class="bg-white rounded-xl md:rounded-2xl border border-gray-100 shadow-sm p-4 md:p-5">
                <div class="text-xs text-gray-400 mb-1">Total Conversations</div>
                <div class="text-xl md:text-2xl font-bold text-gray-800"><?php echo e($totalConversations); ?></div>
                <div class="text-xs text-gray-400 mt-1"><?php echo e($resolvedConversations); ?> resolved · <?php echo e($openConversations); ?> open</div>
            </div>

            <div class="bg-white rounded-xl md:rounded-2xl border border-gray-100 shadow-sm p-4 md:p-5">
                <div class="text-xs text-gray-400 mb-1">Avg. First Response</div>
                <div class="text-xl md:text-2xl font-bold text-gray-800">
                    <?php if($avgResponseMinutes !== null): ?>
                        <?php echo e($avgResponseMinutes < 60 ? round($avgResponseMinutes) . ' min' : round($avgResponseMinutes / 60, 1) . ' hr'); ?>

                    <?php else: ?>
                        —
                    <?php endif; ?>
                </div>
                <div class="text-xs text-gray-400 mt-1">Time to first agent reply</div>
            </div>

            <div class="bg-white rounded-xl md:rounded-2xl border border-gray-100 shadow-sm p-4 md:p-5">
                <div class="text-xs text-gray-400 mb-1">Avg. Resolution Time</div>
                <div class="text-xl md:text-2xl font-bold text-gray-800">
                    <?php if($avgResolutionMinutes !== null): ?>
                        <?php echo e($avgResolutionMinutes < 60 ? round($avgResolutionMinutes) . ' min' : round($avgResolutionMinutes / 60, 1) . ' hr'); ?>

                    <?php else: ?>
                        —
                    <?php endif; ?>
                </div>
                <div class="text-xs text-gray-400 mt-1">Open to resolved</div>
            </div>

            <div class="bg-white rounded-xl md:rounded-2xl border border-gray-100 shadow-sm p-4 md:p-5">
                <div class="text-xs text-gray-400 mb-1">Avg. Rating</div>
                <div class="text-xl md:text-2xl font-bold text-gray-800 flex items-center gap-1">
                    <?php if($avgRating): ?>
                        <?php echo e(number_format($avgRating, 1)); ?> <span class="text-amber-400 text-base">★</span>
                    <?php else: ?>
                        —
                    <?php endif; ?>
                </div>
                <div class="text-xs text-gray-400 mt-1"><?php echo e($ratingCount); ?> rating<?php echo e($ratingCount == 1 ? '' : 's'); ?></div>
            </div>

        </div>

        
        <div class="grid grid-cols-1 lg:grid-cols-3 gap-4 md:gap-6">

            <div class="lg:col-span-2 bg-white rounded-2xl border border-gray-100 shadow-sm p-4 md:p-5">
                <h3 class="text-sm font-semibold text-gray-700 mb-3">Conversations — Last 14 Days</h3>
                <canvas id="chatsPerDayChart" height="90"></canvas>
            </div>

            <div class="bg-white rounded-2xl border border-gray-100 shadow-sm p-4 md:p-5">
                <h3 class="text-sm font-semibold text-gray-700 mb-3">Rating Distribution</h3>
                <?php if($ratingCount > 0): ?>
                    <canvas id="ratingChart" height="140"></canvas>
                <?php else: ?>
                    <div class="text-center text-gray-400 text-sm py-10">No ratings yet</div>
                <?php endif; ?>
            </div>

        </div>

        
        <div class="bg-white rounded-2xl border border-gray-100 shadow-sm p-4 md:p-5">
            <h3 class="text-sm font-semibold text-gray-700 mb-3">CSAT Rating Trend — Last 14 Days</h3>
            <?php if($ratingCount > 0): ?>
                <canvas id="ratingTrendChart" height="70"></canvas>
            <?php else: ?>
                <div class="text-center text-gray-400 text-sm py-10">No ratings yet</div>
            <?php endif; ?>
        </div>

        
        <?php if($isOwner): ?>
        <div class="bg-white rounded-2xl border border-gray-100 shadow-sm overflow-hidden">
            <h3 class="text-sm font-semibold text-gray-700 px-5 py-4 border-b">Performance by Agent</h3>
            <?php if($chatsPerAgent->count() > 0): ?>
            <table class="w-full text-sm">
                <thead>
                    <tr class="text-xs text-gray-400 uppercase text-left">
                        <th class="px-5 py-2 font-medium">Agent</th>
                        <th class="px-5 py-2 font-medium">Total Chats</th>
                        <th class="px-5 py-2 font-medium">Resolved</th>
                        <th class="px-5 py-2 font-medium">Avg. Rating</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $chatsPerAgent; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $agent): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr class="border-t">
                        <td class="px-5 py-3 font-medium text-gray-800"><?php echo e($agent['name']); ?></td>
                        <td class="px-5 py-3 text-gray-600"><?php echo e($agent['total']); ?></td>
                        <td class="px-5 py-3 text-gray-600"><?php echo e($agent['resolved']); ?></td>
                        <td class="px-5 py-3 text-gray-600">
                            <?php if($agent['avg_rating']): ?>
                                <?php echo e(number_format($agent['avg_rating'], 1)); ?> <span class="text-amber-400">★</span>
                            <?php else: ?>
                                —
                            <?php endif; ?>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
            <?php else: ?>
            <div class="text-center text-gray-400 text-sm py-10">No agent activity yet</div>
            <?php endif; ?>
        </div>
        <?php endif; ?>

    </div>
</div>

<script>
const chatsPerDayData = <?php echo json_encode($chatsPerDay, 15, 512) ?>;

new Chart(document.getElementById('chatsPerDayChart'), {
    type: 'bar',
    data: {
        labels: chatsPerDayData.map(d => d.label),
        datasets: [{
            label: 'Conversations',
            data: chatsPerDayData.map(d => d.count),
            backgroundColor: '#6366f1',
            borderRadius: 6,
            maxBarThickness: 28
        }]
    },
    options: {
        plugins: { legend: { display: false } },
        scales: {
            y: { beginAtZero: true, ticks: { precision: 0 } },
            x: { grid: { display: false } }
        }
    }
});

<?php if($ratingCount > 0): ?>
const ratingData = <?php echo json_encode($ratingDistribution, 15, 512) ?>;
new Chart(document.getElementById('ratingChart'), {
    type: 'bar',
    data: {
        labels: Object.keys(ratingData).map(k => k + ' ★'),
        datasets: [{
            data: Object.values(ratingData),
            backgroundColor: '#f59e0b',
            borderRadius: 6,
            maxBarThickness: 22
        }]
    },
    options: {
        indexAxis: 'y',
        plugins: { legend: { display: false } },
        scales: {
            x: { beginAtZero: true, ticks: { precision: 0 } }
        }
    }
});
<?php endif; ?>

<?php if($ratingCount > 0): ?>
const trendData = <?php echo json_encode($ratingTrend, 15, 512) ?>;
new Chart(document.getElementById('ratingTrendChart'), {
    type: 'line',
    data: {
        labels: trendData.map(d => d.label),
        datasets: [{
            label: 'Avg Rating',
            data: trendData.map(d => d.avg),
            borderColor: '#f59e0b',
            backgroundColor: 'rgba(245, 158, 11, 0.1)',
            fill: true,
            tension: 0.35,
            spanGaps: true,
            pointRadius: trendData.map(d => d.avg === null ? 0 : 3),
            pointBackgroundColor: '#f59e0b'
        }]
    },
    options: {
        plugins: {
            legend: { display: false },
            tooltip: {
                callbacks: {
                    label: function(ctx) {
                        var d = trendData[ctx.dataIndex];
                        return d.avg === null ? 'No ratings' : d.avg + ' ★ (' + d.count + ' rating' + (d.count === 1 ? '' : 's') + ')';
                    }
                }
            }
        },
        scales: {
            y: { min: 0, max: 5, ticks: { stepSize: 1 } },
            x: { grid: { display: false } }
        }
    }
});
<?php endif; ?>
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home4/topscbtk/knights.topscripts.in/chatbot_laravel/resources/views/agent/analytics.blade.php ENDPATH**/ ?>