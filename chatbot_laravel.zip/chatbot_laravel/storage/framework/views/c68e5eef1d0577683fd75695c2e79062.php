

<?php $__env->startSection('content'); ?>
<div class="max-w-md mx-auto">

    
    <div class="bg-white rounded-xl shadow-sm border p-8 mb-6">
        <div class="text-center">
            <div class="w-20 h-20 rounded-full mx-auto mb-4 flex items-center justify-center overflow-hidden"
                 style="background:linear-gradient(135deg,#6366f1,#8b5cf6);">
                <?php if(auth()->user()->avatar): ?>
                    <img src="<?php echo e(auth()->user()->avatar); ?>" alt="<?php echo e(auth()->user()->name); ?>" class="w-full h-full object-cover">
                <?php else: ?>
                    <span class="text-white text-2xl font-bold"><?php echo e(strtoupper(substr(auth()->user()->name, 0, 1))); ?></span>
                <?php endif; ?>
            </div>
            <h2 class="font-semibold text-gray-800"><?php echo e(auth()->user()->name); ?></h2>
            <p class="text-xs text-gray-400 mt-0.5"><?php echo e(ucfirst(auth()->user()->role)); ?></p>

            <?php if(session('success')): ?>
            <div class="mt-4 bg-green-50 border border-green-200 text-green-700 px-4 py-2.5 rounded-lg text-xs font-medium">
                ✓ <?php echo e(session('success')); ?>

            </div>
            <?php endif; ?>

            <form method="POST" action="<?php echo e(route('agent.profile.avatar')); ?>" enctype="multipart/form-data" class="mt-5">
                <?php echo csrf_field(); ?>
                <label class="block cursor-pointer">
                    <span class="inline-block px-4 py-2 rounded-lg text-xs font-semibold bg-indigo-50 text-indigo-600 hover:bg-indigo-100">
                        📷 Choose Photo
                    </span>
                    <input type="file" name="avatar" accept="image/png,image/jpeg,image/webp" class="hidden"
                           onchange="this.form.querySelector('button').disabled=false; this.form.querySelector('#avatar-filename').textContent=this.files[0]?.name || '';">
                </label>
                <div id="avatar-filename" class="text-xs text-gray-400 mt-2"></div>
                <button type="submit" disabled
                    class="mt-3 w-full bg-indigo-600 text-white py-2 rounded-lg text-xs font-semibold hover:bg-indigo-700 disabled:opacity-40 disabled:cursor-not-allowed transition">
                    Upload Photo
                </button>
            </form>

            <?php if(auth()->user()->avatar): ?>
            <form method="POST" action="<?php echo e(route('agent.profile.avatar.remove')); ?>" class="mt-2"
                  onsubmit="return confirm('Remove your profile photo?');">
                <?php echo csrf_field(); ?>
                <?php echo method_field('DELETE'); ?>
                <button type="submit" class="text-xs text-red-500 hover:text-red-700">Remove photo</button>
            </form>
            <?php endif; ?>
        </div>
    </div>

    <div class="bg-white rounded-xl shadow-sm border p-8">
        <div class="text-center mb-6">
            <div class="w-14 h-14 bg-indigo-100 rounded-full flex items-center justify-center mx-auto mb-3">
                <svg class="w-7 h-7 text-indigo-600" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" d="M15 7a2 2 0 012 2m4 0a6 6 0 01-7.743 5.743L11 17H9v2H7v2H4a1 1 0 01-1-1v-2.586a1 1 0 01.293-.707l5.964-5.964A6 6 0 1121 9z"/>
                </svg>
            </div>
            <h1 class="text-xl font-bold text-gray-800">Change Password</h1>
            <p class="text-sm text-gray-500 mt-1">Update your account password</p>
        </div>

        <?php if(session('error')): ?>
        <div class="mb-4 bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-lg text-sm font-medium">
            ✗ <?php echo e(session('error')); ?>

        </div>
        <?php endif; ?>

        <form method="POST" action="<?php echo e(route('agent.password.update')); ?>">
            <?php echo csrf_field(); ?>

            <div class="mb-4">
                <label class="block text-xs font-semibold text-gray-500 uppercase tracking-wide mb-2">Current Password</label>
                <input type="password" name="current_password" required
                    class="w-full border rounded-lg px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-400 <?php $__errorArgs = ['current_password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-400 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                <?php $__errorArgs = ['current_password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p class="text-red-500 text-xs mt-1"><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="mb-4">
                <label class="block text-xs font-semibold text-gray-500 uppercase tracking-wide mb-2">New Password</label>
                <input type="password" name="password" required minlength="6"
                    class="w-full border rounded-lg px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-400 <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-400 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p class="text-red-500 text-xs mt-1"><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="mb-6">
                <label class="block text-xs font-semibold text-gray-500 uppercase tracking-wide mb-2">Confirm New Password</label>
                <input type="password" name="password_confirmation" required minlength="6"
                    class="w-full border rounded-lg px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-400">
            </div>

            <button type="submit"
                class="w-full bg-indigo-600 text-white py-2.5 rounded-lg text-sm font-semibold hover:bg-indigo-700 transition">
                Update Password
            </button>
        </form>

        <div class="mt-4 text-center">
            <a href="<?php echo e(route('agent.dashboard')); ?>" class="text-sm text-gray-400 hover:text-gray-600">← Back to Dashboard</a>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home4/topscbtk/knights.topscripts.in/chatbot_laravel/resources/views/agent/password/change.blade.php ENDPATH**/ ?>