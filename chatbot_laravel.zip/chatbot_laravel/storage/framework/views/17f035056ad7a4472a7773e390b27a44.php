
<?php $__env->startSection('content'); ?>
<div class="max-w-4xl mx-auto py-10 px-4">
  <h1 class="text-2xl font-bold text-gray-900 mb-8">Billing & Subscription</h1>

  <?php if(session('success')): ?>
  <div class="mb-6 p-4 bg-green-50 border border-green-200 rounded-xl text-green-800 text-sm"><?php echo e(session('success')); ?></div>
  <?php endif; ?>
  <?php if(session('error')): ?>
  <div class="mb-6 p-4 bg-red-50 border border-red-200 rounded-xl text-red-800 text-sm"><?php echo e(session('error')); ?></div>
  <?php endif; ?>

  
  <div class="bg-white border border-gray-200 rounded-2xl p-6 mb-6">
    <div class="flex items-center justify-between">
      <div>
        <p class="text-sm text-gray-500">Current plan</p>
        <p class="text-2xl font-bold text-gray-900 capitalize mt-1"><?php echo e($tenant->plan ?? 'None'); ?></p>
        <p class="text-sm mt-1">
          Status:
          <span class="font-semibold <?php echo e($tenant->is_active ? 'text-green-600' : 'text-red-500'); ?>">
            <?php echo e($tenant->is_active ? 'Active' : 'Inactive'); ?>

          </span>
        </p>
        <?php if($tenant->subscription_ends_at): ?>
        <p class="text-xs text-gray-400 mt-1">Cancels on <?php echo e(\Carbon\Carbon::parse($tenant->subscription_ends_at)->format('M d, Y')); ?></p>
        <?php endif; ?>
      </div>
      <div class="flex flex-col gap-2">
        <a href="<?php echo e(route('billing.pricing')); ?>" class="px-5 py-2 bg-indigo-600 text-white text-sm font-semibold rounded-xl hover:bg-indigo-700 transition text-center">
          <?php echo e($tenant->is_active ? 'Change Plan' : 'Subscribe'); ?>

        </a>
        <?php if($tenant->is_active && !$tenant->subscription_ends_at): ?>
        <form action="<?php echo e(route('billing.cancel')); ?>" method="POST" onsubmit="return confirm('Cancel subscription?')">
          <?php echo csrf_field(); ?>
          <button class="w-full px-5 py-2 border border-red-300 text-red-600 text-sm font-semibold rounded-xl hover:bg-red-50 transition">Cancel</button>
        </form>
        <?php endif; ?>
      </div>
    </div>
  </div>

  
  <?php if(isset($plans[$tenant->plan ?? ''])): ?>
  <?php $currentPlan = $plans[$tenant->plan]; ?>
  <div class="bg-white border border-gray-200 rounded-2xl p-6 mb-6">
    <h2 class="font-semibold text-gray-800 mb-4">Plan limits</h2>
    <div class="grid grid-cols-2 gap-4">
      <div class="bg-gray-50 rounded-xl p-4">
        <p class="text-xs text-gray-500">Max agents</p>
        <p class="text-2xl font-bold text-gray-900"><?php echo e($currentPlan['agents'] == 999 ? '∞' : $currentPlan['agents']); ?></p>
      </div>
      <div class="bg-gray-50 rounded-xl p-4">
        <p class="text-xs text-gray-500">Chats / month</p>
        <p class="text-2xl font-bold text-gray-900"><?php echo e($currentPlan['chats'] == 999999 ? '∞' : number_format($currentPlan['chats'])); ?></p>
      </div>
    </div>
  </div>
  <?php endif; ?>

  
  <?php if(count($invoices)): ?>
  <div class="bg-white border border-gray-200 rounded-2xl p-6">
    <h2 class="font-semibold text-gray-800 mb-4">Invoice history</h2>
    <table class="w-full text-sm">
      <thead><tr class="text-left text-gray-400 border-b border-gray-100">
        <th class="pb-3 font-medium">Date</th>
        <th class="pb-3 font-medium">Amount</th>
        <th class="pb-3 font-medium">Status</th>
        <th class="pb-3 font-medium"></th>
      </tr></thead>
      <tbody>
        <?php $__currentLoopData = $invoices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $invoice): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr class="border-b border-gray-50">
          <td class="py-3"><?php echo e(\Carbon\Carbon::createFromTimestamp($invoice->created)->format('M d, Y')); ?></td>
          <td class="py-3">$<?php echo e(number_format($invoice->amount_paid / 100, 2)); ?></td>
          <td class="py-3">
            <span class="px-2 py-0.5 rounded-full text-xs font-semibold <?php echo e($invoice->status === 'paid' ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-600'); ?>">
              <?php echo e(ucfirst($invoice->status)); ?>

            </span>
          </td>
          <td class="py-3 text-right">
            <?php if($invoice->invoice_pdf): ?>
            <a href="<?php echo e($invoice->invoice_pdf); ?>" target="_blank" class="text-indigo-600 text-xs hover:underline">Download PDF</a>
            <?php endif; ?>
          </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </tbody>
    </table>
  </div>
  <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home4/topscbtk/knights.topscripts.in/chatbot_laravel/resources/views/billing/dashboard.blade.php ENDPATH**/ ?>